/* ==================================================================
 * 20-backup.js
 * النسخ الاحتياطي: النسخ السحابي (يعمل داخل claude.ai فقط) وملف نسخة لكل المشاريع.
 *
 * يعرّف: cloudDb، cloudSoon، cloudPush، cloudList، cloudSheet، allFile
 * يعتمد على: 01-core.js، 05-persistence.js، 07-projects.js، 08-project-io.js،
 *            22-toolbar.js
 * ================================================================== */

// ---- نسخ احتياطي: سحابي (مساحة حسابك الخاصة في claude.ai) وملف لكل المشاريع ----
async function cloudDb(){
  try{if(!window.claude)return null;const db=await claude.use('db'),us=await claude.use('user');if(!db||!us)return null;const id=await us.id();return id?{db,id}:null}catch(e){return null}
}

function cloudSoon(){if(!ST.cloud)return;clearTimeout(cloudT);cloudT=setTimeout(()=>cloudPush(false),5000)}

async function cloudPush(all){
  const c=await cloudDb();if(!c){toast('النسخ السحابي غير متاح هنا');return false}
  try{
    const col=c.db.collection('data/users/'+c.id),t=Date.now();
    for(const p of(all?PJ:PJ.filter(p=>p.id===pid))){
      const js=JSON.stringify(p.id===pid?{shapes,V,LY,cl}:(lsGet('p:'+p.id)||{shapes:[]}));
      if(js.length>240000){toast(`المشروع «${p.name}» كبير جدًا للنسخ السحابي`);continue}
      await col.doc('p_'+p.id).set({name:p.name,t,d:js});
    }
    await col.doc('meta').set({t,PJ,pid});
    cloudAt=t;ST.bk=t;lsSet('set',{S,D,ST});return true;
  }catch(e){toast('تعذّر النسخ السحابي');return false}
}

async function cloudList(){
  const c=await cloudDb();if(!c)return null;
  try{const s=await c.db.collection('data/users/'+c.id).get();return s.docs.filter(d=>d.id.startsWith('p_')).map(d=>({id:d.id,...d.data()}))}catch(e){return null}
}

async function cloudSheet(){
  const sh=$('#sheet');
  sh.innerHTML='<b>الاستعادة من السحابة</b><div class="pl" id="cld">جارٍ التحميل…</div><button id="ok">تم</button>';
  $('#ok').onclick=()=>{sh.classList.remove('on');upd()};sh.classList.add('on');$('#ctx').style.display='none';
  const rows=await cloudList(),box=$('#cld');box.textContent='';
  if(!rows){box.textContent='تعذّر الوصول إلى السحابة: سجّل الدخول وافتح الصفحة من claude.ai';return}
  if(!rows.length){box.textContent='لا توجد نسخ سحابية بعد';return}
  rows.sort((a,b)=>b.t-a.t).forEach(r=>{
    const b=document.createElement('button');b.className='pi';b.textContent=`${r.name} · ${new Date(r.t).toISOString().slice(0,16).replace('T',' ')}`;
    b.onclick=()=>{try{const d=JSON.parse(r.d);newP(`${r.name} (مستعاد)`,d.shapes||[],d.LY?{LY:d.LY,cl:d.cl}:null);sh.classList.remove('on');toast('تمت الاستعادة كمشروع جديد')}catch(e){toast('النسخة تالفة')}};
    box.append(b);
  });
}

async function allFile(){
  save();
  const projects=PJ.map(p=>({name:p.name,d:p.id===pid?{shapes,V,LY,cl}:(lsGet('p:'+p.id)||{shapes:[]})}));
  const r=await saveBlob('plan-backup-'+new Date().toISOString().slice(0,10)+'.json',new Blob([JSON.stringify({app:'plan-backup',v:1,projects})],{type:'application/json'}));
  if(r==='ok'){ST.bk=Date.now();save();toast('تم حفظ كل المشاريع');upd()}else if(r==='err')toast('الحفظ غير متاح هنا');
}

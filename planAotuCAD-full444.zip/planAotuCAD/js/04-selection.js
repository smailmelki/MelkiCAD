/* ==================================================================
 * 04-selection.js
 * التحديد: اختبار اللمس (hit)، التحديد بإطار، مقابض التعديل والتدوير، وإجراءات
 * شريط السياق (نسخ، لصق، حذف، تحديد الكل، تدوير، تحجيم).
 *
 * يعرّف: selC، grips، boxSel، gripAt، hit، transformShapeScale، transformSheet
 * يعتمد على: 01-core.js، 02-geometry.js، 05-persistence.js، 06-layers.js،
 *            09-render.js، 10-dimensions.js، 22-toolbar.js
 * ================================================================== */

function selC(){const b=sel.map(i=>bx(shapes[i]));return[(Math.min(...b.map(q=>q.x))+Math.max(...b.map(q=>q.X)))/2,(Math.min(...b.map(q=>q.y))+Math.max(...b.map(q=>q.Y)))/2]}
// المقابض: نقاط التعديل + مقبض التدوير فوق التحديد
function grips(){
  if(tool!=='select'||!sel.length||(g&&g.k==='box'))return[];
  const r=[],s=sel.length===1?shapes[sel[0]]:null,b=sel.map(i=>bx(shapes[i])),x0=Math.min(...b.map(q=>q.x)),x1=Math.max(...b.map(q=>q.X)),y0=Math.min(...b.map(q=>q.y)),top=w2s((x0+x1)/2,y0);
  if(!sel.every(i=>shapes[i].t==='door'||shapes[i].t==='win'))r.push({id:'rot',sp:[top[0],top[1]-34],top});
  const add=(id,p)=>r.push({id,sp:w2s(...p)});
  if(s){if(s.t==='dim'){add('a',s.a);add('b',s.b);const d=dimPts(s);add('o',[(d[0][0]+d[1][0])/2,(d[0][1]+d[1][1])/2])}else if(s.t==='line'||s.t==='wall'){add('a',s.a);add('b',s.b)}else if(s.t==='tri')s.p.forEach((q,i)=>add(i,q));else if(s.t==='rect'||s.t==='furn')rc(s).forEach((q,i)=>add(i,q));else if(s.t==='circle')add('r',[s.x+s.r,s.y])}
  return r;
}
// تحديد بإطار: من اليسار لليمين = داخلي (الأشكال داخل الإطار بالكامل)، من اليمين لليسار = بالتقاطع (كل ما يلمسه الإطار)
function boxSel(){
  if(!box)return[];
  const a=s2w(box.x0,box.y0),b=s2w(box.x1,box.y1),x=Math.min(a[0],b[0]),X=Math.max(a[0],b[0]),y=Math.min(a[1],b[1]),Y=Math.max(a[1],b[1]),cross=box.x1<box.x0;
  return shapes.map((_,i)=>i).filter(i=>{if(!ed(shapes[i]))return false;const r=bx(shapes[i]);return cross?r.x<=X&&r.X>=x&&r.y<=Y&&r.Y>=y:r.x>=x&&r.X<=X&&r.y>=y&&r.Y<=Y});
}

const gripAt=p=>grips().find(q=>Math.hypot(q.sp[0]-p[0],q.sp[1]-p[1])<=22);

function hit(px,py){
  for(let i=shapes.length-1;i>=0;i--){const s=shapes[i];if(!ed(s))continue;
    if(s.t==='circle'){const q=w2s(s.x,s.y);if(Math.hypot(px-q[0],py-q[1])<=s.r*V.s+8)return i}
    else if(s.t==='rect'||s.t==='furn'){const q=s2w(px,py),cx=s.x+s.w/2,cy=s.y+s.h/2,c=Math.cos(-(s.rot||0)),n=Math.sin(-(s.rot||0)),dx=q[0]-cx,dy=q[1]-cy,m=8/V.s;if(Math.abs(dx*c-dy*n)<=s.w/2+m&&Math.abs(dx*n+dy*c)<=s.h/2+m)return i}
    else if(s.t==='tri'){const q=s.p.map(r=>w2s(...r)),sg=(a,b)=>(px-b[0])*(a[1]-b[1])-(a[0]-b[0])*(py-b[1]),d=[sg(q[0],q[1]),sg(q[1],q[2]),sg(q[2],q[0])];if(!(d.some(v=>v<0)&&d.some(v=>v>0)))return i}
    else if(s.t==='text'||s.t==='north'){const n=nb(s),q=s2w(px,py),dx=q[0]-s.x,dy=q[1]-s.y,c=Math.cos(-n.rot),sn=Math.sin(-n.rot),m=8/V.s;if(Math.abs(dx*c-dy*sn)<=n.w/2+m&&Math.abs(dx*sn+dy*c)<=n.h/2+m)return i}
    else if(s.t==='dim'){const q=dimPts(s).map(r=>w2s(...r));if(dseg(px,py,q[0][0],q[0][1],q[1][0],q[1][1])<16)return i}
    else{const q=pts(s).map(r=>w2s(...r));for(let j=1;j<q.length;j++)if(dseg(px,py,q[j-1][0],q[j-1][1],q[j][0],q[j][1])<Math.max(16,(s.th||0)*V.s/2+8))return i}}
  return -1;
}

$('#cp').onclick=()=>{clip=sel.map(i=>JSON.parse(JSON.stringify(shapes[i])));upd()};

$('#ps').onclick=()=>{
  if(!clip.length)return;snap();
  const r=clip.map(bx),x0=Math.min(...r.map(q=>q.x)),y0=Math.min(...r.map(q=>q.y)),x1=Math.max(...r.map(q=>q.X)),y1=Math.max(...r.map(q=>q.Y)),c=s2w(W/2,H/2);
  const dx=grid(c[0]-(x0+x1)/2),dy=grid(c[1]-(y0+y1)/2),n=clip.map(s=>{const t=copy(s);mv(t,s,dx,dy);return t});fixLinks(clip,n);
  sel=n.map((_,i)=>shapes.length+i);shapes.push(...n);save();upd();draw();
};

$('#del').onclick=()=>{if(sel.length){snap();shapes=shapes.filter((_,i)=>!sel.includes(i));sel=[];save();upd();draw()}};

$('#all').onclick=()=>{sel=shapes.map((_,i)=>i).filter(i=>ed(shapes[i]));upd();draw()};

function transformShapeScale(s,o,c,k){
  const sc=q=>[c[0]+(q[0]-c[0])*k,c[1]+(q[1]-c[1])*k];
  if(['line','wall','dim'].includes(s.t)){s.a=sc(o.a);s.b=sc(o.b);if(s.t==='dim')s.off=o.off*k;if(s.t==='wall'&&o.th)s.th=o.th*k}
  else if(Array.isArray(o.p))s.p=o.p.map(sc);
  else if(s.t==='circle'||s.t==='arc'){s.x=c[0]+(o.x-c[0])*k;s.y=c[1]+(o.y-c[1])*k;s.r=o.r*k}
  else if(s.t==='ellipse'){s.x=c[0]+(o.x-c[0])*k;s.y=c[1]+(o.y-c[1])*k;s.rx=o.rx*k;s.ry=o.ry*k}
  else if(s.t==='rect'||s.t==='furn'){const m=sc([o.x+o.w/2,o.y+o.h/2]);s.w=o.w*k;s.h=o.h*k;s.x=m[0]-s.w/2;s.y=m[1]-s.h/2}
  else if(['text','north','door','win'].includes(s.t)){s.x=c[0]+(o.x-c[0])*k;s.y=c[1]+(o.y-c[1])*k;s.h=o.h*k;if(o.w!==undefined)s.w=o.w*k;if(o.th!==undefined)s.th=o.th*k}
}

function transformSheet(kind){if(!sel.length)return;const sh=$('#sheet'),single=sel.length===1?shapes[sel[0]]:null;sh.innerHTML=kind==='rotate'?'<b>تدوير العناصر</b><label>زاوية الدوران (درجة)<input id="trval" type="number" step="0.1" value="90" dir="ltr"></label><p>موجب عكس عقارب الساعة، حول مركز التحديد.</p><button id="applytr">تطبيق</button><button id="ok">إلغاء</button>':'<b>تحجيم العناصر</b><label>عامل التحجيم<input id="trval" type="number" min="0.01" step="0.1" value="2" dir="ltr"></label><p>مثال: 2 تكبير للضعف، و0.5 تصغير إلى النصف. يتم التحجيم حول مركز التحديد.</p><button id="applytr">تطبيق</button><button id="ok">إلغاء</button>';$('#applytr').onclick=()=>{const v=num($('#trval').value);if(!Number.isFinite(v)||(kind==='scale'?v<=0:!Number.isFinite(v))){toast('أدخل قيمة صحيحة');return}snap();const c=selC();if(kind==='rotate'){const a=v*Math.PI/180;sel.forEach(i=>rotS(shapes[i],copy(shapes[i]),c,a))}else sel.forEach(i=>{const o=copy(shapes[i]);transformShapeScale(shapes[i],o,c,v)});save();sh.classList.remove('on');upd();draw()};$('#ok').onclick=()=>{sh.classList.remove('on');upd()};sh.classList.add('on');$('#ctx').style.display='none'}

$('#rt').onclick=()=>transformSheet('rotate');$('#scale').onclick=()=>transformSheet('scale');

/* ==================================================================
 * 15-properties.js
 * خصائص العنصر: لوحة الخيارات (اللون، السمك، الطبقة، التعبئة، القياسات) وشريط
 * الإدخال الرقمي الشامل dyn.
 *
 * يعرّف: opts، dynS، dynFields، hideDyn، dynAngle، dynSpec، showDyn، applyDyn
 * يعتمد على: 01-core.js، 02-geometry.js، 05-persistence.js، 09-render.js،
 *            22-toolbar.js
 * ================================================================== */

// ---- خيارات: اللون والسمك والأبعاد ----
function opts(){
  if(!sel.length)return;
  const sh=$('#sheet'),s1=sel.length===1?shapes[sel[0]]:null,first=shapes[sel[0]],F=[];let done=0;
  const once=()=>{if(!done){snap();done=1}};
  if(s1){
    if(!['line','wall','dim','free','polyline','door','win','text','north','furn'].includes(s1.t))F.push(['name','الاسم',s1.name||'']);
    const b=bx(s1);
    if(s1.t==='ellipse')F.push(['rx','نصف المحور الأفقي ('+uA()+')',fu(s1.rx)],['ry','نصف المحور الرأسي ('+uA()+')',fu(s1.ry)],['ang','الزاوية (°)',f(((s1.rot||0)*180/Math.PI)%360)]);
    if(s1.t==='rect'||s1.t==='furn')F.push(['w','العرض ('+uA()+')',fu(s1.w)],['h','الطول ('+uA()+')',fu(s1.h)],['ang','الزاوية (°)',f(((s1.rot||0)*180/Math.PI)%360)]);else if(s1.t==='tri')F.push(['w','العرض ('+uA()+')',fu(b.X-b.x)],['h','الطول ('+uA()+')',fu(b.Y-b.y)]);
    else if(s1.t==='circle')F.push(['r','نصف القطر ('+uA()+')',fu(s1.r)]);
    else if(s1.t==='text')F.push(['txt','النص',s1.txt],['h','الحجم ('+uA()+')',fu(s1.h)],['ang','الزاوية (°)',f(((s1.a||0)*180/Math.PI)%360)]);else if(s1.t==='north')F.push(['h','الحجم ('+uA()+')',fu(s1.h)],['ang','الزاوية (°)',f(((s1.a||0)*180/Math.PI)%360)]);
    else if(s1.t==='dim')F.push(['off','الإزاحة ('+uA()+')',fu(s1.off)]);else if(s1.t==='door'||s1.t==='win')F.push(['w','العرض ('+uA()+')',fu(s1.w)]);else if(s1.t==='line'||s1.t==='wall'){F.push(['L','الطول ('+uA()+')',fu(len(s1))]);if(s1.t==='wall')F.push(['th','سمك الجدار (سم)',f(s1.th*100)])}
  }
  sh.innerHTML=`<b>اللون</b><div class="sws">${COLS.map(c=>`<button class="sw${c?'':' auto'}${c===(first.col||'')?' on':''}" data-c="${c}" style="${c?'background:'+c:''}" aria-label="لون"></button>`).join('')}</div>`
    +`<label>الطبقة<select id="elementLayer">${LY.map(l=>`<option value="${l.id}" ${l.id===(first.ly||LY[0]?.id)?'selected':''}>${l.name}</option>`).join('')}</select></label>`
    +`<label>السُّمك<input type="range" id="lw" min="1" max="10" step=".5"><b id="lwv"></b></label>`
    +(sel.some(i=>['rect','circle','ellipse','tri','polygon'].includes(shapes[i].t))?`<b>التعبئة</b><div class="chips" id="fk">${[['','بدون'],['solid','لون'],['tile','بلاط'],['wood','خشب'],['hatch','تهشير'],['dots','نقاط']].map(([v,l])=>`<button class="chip${(first.fk||'')===v?' on':''}" data-v="${v}">${l}</button>`).join('')}</div><div class="sws" id="fc">${COLS.map(c=>`<button class="sw${c?'':' auto'}${c===(first.fc||'')?' on':''}" data-c="${c}" style="${c?'background:'+c:''}" aria-label="لون التعبئة"></button>`).join('')}</div>`:'')
    +F.map(x=>`<label>${x[1]}<input data-k="${x[0]}" ${x[0]==='name'||x[0]==='txt'?'type="text"':'dir="ltr" inputmode="decimal"'}></label>`).join('')
    +(s1&&s1.t==='door'?'<div class="row"><button class="fl" data-f="f">قلب الفتح</button><button class="fl" data-f="h">عكس المفصلة</button></div>':'')
    +(s1&&s1.t==='rect'?'<button class="fl" id="tw">إضافة جدران حولها</button>':'')+'<button id="ok">تم</button>';
  F.forEach(x=>sh.querySelector(`[data-k="${x[0]}"]`).value=x[2]);
  $('#elementLayer').onchange=e=>{once();const id=e.target.value;sel.forEach(i=>{shapes[i].ly=id});save();draw()};
  $('#lw').value=first.lw||2;$('#lwv').textContent=first.lw||2;
  sh.querySelectorAll('.sws:not(#fc) .sw').forEach(b=>b.onclick=()=>{
    once();const c=b.dataset.c;sel.forEach(i=>{shapes[i].col=c||undefined});D.col=c;
    sh.querySelectorAll('.sws:not(#fc) .sw').forEach(x=>x.classList.toggle('on',x===b));save();draw();
  });
  $('#lw').oninput=e=>{once();const v=+e.target.value;sel.forEach(i=>{shapes[i].lw=v});D.lw=v;$('#lwv').textContent=v;save();draw()};
  sh.querySelectorAll('.fl').forEach(b=>b.onclick=()=>{once();s1[b.dataset.f]*=-1;save();draw()});
  const isC=s=>['rect','circle','ellipse','tri','polygon'].includes(s.t);
  sh.querySelectorAll('#fk .chip').forEach(b=>{b.onclick=()=>{once();const v=b.dataset.v||undefined;sel.forEach(i=>{if(isC(shapes[i]))shapes[i].fk=v});sh.querySelectorAll('#fk .chip').forEach(x=>x.classList.toggle('on',x===b));save();draw()}});
  sh.querySelectorAll('#fc .sw').forEach(b=>{b.onclick=()=>{once();const c=b.dataset.c||undefined;sel.forEach(i=>{if(isC(shapes[i]))shapes[i].fc=c});sh.querySelectorAll('#fc .sw').forEach(x=>x.classList.toggle('on',x===b));save();draw()}});
  const tw=$('#tw');if(tw)tw.onclick=()=>{once();const k=rc(s1);k.forEach((q,j)=>shapes.push({t:'wall',a:q,b:k[(j+1)%4],th:D.th||.2,ly:s1.ly,col:s1.col}));sel=[];sh.classList.remove('on');save();upd();draw()};
  $('#ok').onclick=()=>{
    if(s1&&F.length){
      once();const v=k=>{const el=sh.querySelector(`[data-k="${k}"]`);return el?Math.abs(k==='th'?num(el.value):nu(el.value)):0},nm=sh.querySelector('[data-k="name"]');
      if(nm)s1.name=nm.value.trim()||undefined;
      if(s1.t==='ellipse'){s1.rx=v('rx')||s1.rx;s1.ry=v('ry')||s1.ry;const an=sh.querySelector('[data-k="ang"]'),t=an?num(an.value):NaN;if(!isNaN(t))s1.rot=t*Math.PI/180}
      else if(s1.t==='rect'||s1.t==='furn'){const cx=s1.x+s1.w/2,cy=s1.y+s1.h/2;s1.w=v('w')||s1.w;s1.h=v('h')||s1.h;s1.x=cx-s1.w/2;s1.y=cy-s1.h/2;const an=sh.querySelector('[data-k="ang"]'),t=an?num(an.value):NaN;if(!isNaN(t))s1.rot=t*Math.PI/180}
      else if(s1.t==='tri'){const b=bx(s1),W0=b.X-b.x,H0=b.Y-b.y,w=v('w')||W0,h=v('h')||H0;s1.p=s1.p.map(q=>[b.x+(q[0]-b.x)/W0*w,b.y+(q[1]-b.y)/H0*h])}
      else if(s1.t==='circle')s1.r=v('r')||s1.r;
      else if(s1.t==='text'||s1.t==='north'){const tx=sh.querySelector('[data-k="txt"]'),an=sh.querySelector('[data-k="ang"]'),t=an?num(an.value):NaN;if(tx)s1.txt=tx.value.trim()||s1.txt;s1.h=v('h')||s1.h;if(!isNaN(t))s1.a=t*Math.PI/180}
      else if(s1.t==='dim'){const el=sh.querySelector('[data-k="off"]'),t=el?nu(el.value):NaN;if(!isNaN(t))s1.off=t}
      else if(s1.t==='door'||s1.t==='win')s1.w=v('w')||s1.w;
      else if(s1.t==='line'||s1.t==='wall'){const L=v('L'),d=len(s1);if(s1.t==='wall'){s1.th=(v('th')||s1.th*100)/100;D.th=s1.th}if(L>0){const u=d?[(s1.b[0]-s1.a[0])/d,(s1.b[1]-s1.a[1])/d]:[1,0];s1.b=[s1.a[0]+u[0]*L,s1.a[1]+u[1]*L]}}
    }
    sh.classList.remove('on');save();upd();draw();
  };
  sh.classList.add('on');$('#ctx').style.display='none';
}

$('#op').onclick=opts;
// الإدخال الرقمي الشامل: قيم هندسية مناسبة لكل نوع من عناصر الرسم
let dynS=null,dynFields=[];

function hideDyn(){dynS=null;dynFields=[];$('#dyn').classList.remove('on');$('#dynfields').innerHTML=''}

function dynAngle(dx,dy){let a=deg(Math.atan2(-dy,dx));return (a+360)%360}

function dynSpec(s){
  const b=bx(s),cx=(b.x+b.X)/2,cy=(b.y+b.Y)/2;
  if(s.t==='rect')return [['w','العرض',fu(s.w)],['h','الارتفاع',fu(s.h)],['ang','الزاوية °',f(deg(s.rot||0))]];
  if(s.t==='circle')return [['r','نصف القطر',fu(s.r)]];
  if(s.t==='line'||s.t==='wall'||s.t==='dim')return [['L','الطول',fu(len(s))],['ang','الزاوية °',f(dynAngle(s.b[0]-s.a[0],s.b[1]-s.a[1]))],...(s.t==='wall'?[['th','السماكة',fu(s.th)]]:[])];
  if(s.t==='arc')return [['r','نصف القطر',fu(s.r)],['a0','زاوية البداية °',f(deg(s.a0||0))],['a1','زاوية النهاية °',f(deg(s.a1||0))]];
  if(s.t==='ellipse')return [['rx','نصف المحور X',fu(s.rx)],['ry','نصف المحور Y',fu(s.ry)],['ang','زاوية الدوران °',f(deg(s.rot||0))]];
  if(s.t==='tri')return [['w','العرض',fu(b.X-b.x)],['h','الارتفاع',fu(b.Y-b.y)]];
  if(s.t==='polygon'){
    const p=s.p||[],n=p.length,c=p.reduce((a,q)=>[a[0]+q[0]/n,a[1]+q[1]/n],[0,0]),r=n?Math.hypot(p[0][0]-c[0],p[0][1]-c[1]):1;
    return [['r','نصف قطر المضلع',fu(r)],['sides','عدد الأضلاع',String(n)],['ang','زاوية البداية °',f(dynAngle(p[0][0]-c[0],p[0][1]-c[1]))]];
  }
  if(s.t==='polyline'||s.t==='free'){
    const p=s.p||[],n=p.length;if(n<2)return [];
    const a=p[n-2],z=p[n-1];return [['L','طول آخر مقطع',fu(Math.hypot(z[0]-a[0],z[1]-a[1]))],['ang','زاوية آخر مقطع °',f(dynAngle(z[0]-a[0],z[1]-a[1]))]];
  }
  if(s.t==='furn')return [['w','العرض',fu(s.w)],['h','الطول',fu(s.h)],['ang','زاوية الدوران °',f(deg(s.rot||0))]];
  if(s.t==='door'||s.t==='win')return [['w','العرض',fu(s.w)],['ang','زاوية العنصر °',f(deg(s.a||0))]];
  if(s.t==='text'||s.t==='north')return [['h','الحجم',fu(s.h)],['ang','زاوية الدوران °',f(deg(s.a||0))]];
  return [];
}

function showDyn(s){
  if(['furn','dim','door','win'].includes(s?.t)||!S.dyn||!s||!shapes.includes(s)){hideDyn();return}
  dynS=s;dynFields=dynSpec(s);const host=$('#dynfields');host.innerHTML='';
  dynFields.forEach(([k,label,value])=>{
    const wrap=document.createElement('label');wrap.className='df';
    const name=document.createElement('span');name.textContent=label;
    const input=document.createElement('input');input.dataset.dk=k;input.inputMode='decimal';input.dir='ltr';input.value=value;input.autocomplete='off';
    input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();applyDyn()}});
    wrap.append(name,input);host.append(wrap);
  });
  $('#dyn').classList.toggle('on',dynFields.length>0);
  if(!dynFields.length)hideDyn();
}

function applyDyn(){
  const s=dynS;if(!s||!shapes.includes(s)){hideDyn();return}
  const get=k=>{const el=$(`#dynfields [data-dk="${k}"]`);return el?num(el.value):NaN};
  const v=k=>{const n=get(k);return Number.isFinite(n)?n:NaN};
  const old=copy(s);snap();
  const angle=k=>{const n=v(k);return Number.isFinite(n)?rad(n):null};
  if(s.t==='rect'){
    const w=nu($('#dynfields [data-dk="w"]').value),h=nu($('#dynfields [data-dk="h"]').value),a=angle('ang');
    if(w>0)s.w=w;if(h>0)s.h=h;if(a!==null)s.rot=a;
  }else if(s.t==='circle'){const r=nu($('#dynfields [data-dk="r"]').value);if(r>0)s.r=r}
  else if(s.t==='line'||s.t==='wall'||s.t==='dim'){
    const L=nu($('#dynfields [data-dk="L"]').value),a=angle('ang'),d=len(s)||1;
    if(L>0||a!==null){const q=a===null?Math.atan2(-(s.b[1]-s.a[1]),s.b[0]-s.a[0]):a,l=L>0?L:d;s.b=[s.a[0]+l*Math.cos(q),s.a[1]-l*Math.sin(q)];if(s.t==='dim'){s.lb=undefined}}
    if(s.t==='wall'){const th=nu($('#dynfields [data-dk="th"]').value);if(th>0)s.th=th}
  }else if(s.t==='arc'){
    const r=nu($('#dynfields [data-dk="r"]').value),a0=angle('a0'),a1=angle('a1');if(r>0)s.r=r;if(a0!==null)s.a0=a0;if(a1!==null)s.a1=a1;while(s.a1<=s.a0)s.a1+=Math.PI*2;
  }else if(s.t==='ellipse'){
    const rx=nu($('#dynfields [data-dk="rx"]').value),ry=nu($('#dynfields [data-dk="ry"]').value),a=angle('ang');if(rx>0)s.rx=rx;if(ry>0)s.ry=ry;if(a!==null)s.rot=a;
  }else if(s.t==='tri'){
    const b=bx(old),w0=Math.max(.0001,b.X-b.x),h0=Math.max(.0001,b.Y-b.y),w=nu($('#dynfields [data-dk="w"]').value),h=nu($('#dynfields [data-dk="h"]').value);
    s.p=old.p.map(q=>[b.x+(q[0]-b.x)*(w>0?w/w0:1),b.y+(q[1]-b.y)*(h>0?h/h0:1)]);
  }else if(s.t==='polygon'){
    const p=old.p||[],n0=p.length,c=p.reduce((z,q)=>[z[0]+q[0]/n0,z[1]+q[1]/n0],[0,0]),r=nu($('#dynfields [data-dk="r"]').value),sides=Math.round(v('sides')),a=angle('ang');
    const radius=r>0?r:(n0?Math.hypot(p[0][0]-c[0],p[0][1]-c[1]):1),count=Number.isFinite(sides)?clamp(sides,3,32):n0,ang=a===null?(n0?Math.atan2(p[0][1]-c[1],p[0][0]-c[0]):0):-a;
    s.p=Array.from({length:count},(_,i)=>[c[0]+radius*Math.cos(ang+i*2*Math.PI/count),c[1]+radius*Math.sin(ang+i*2*Math.PI/count)]);
  }else if(s.t==='polyline'||s.t==='free'){
    const p=s.p||[],n=p.length;if(n>=2){const a=p[n-2],z=p[n-1],oldL=Math.hypot(z[0]-a[0],z[1]-a[1])||1,L=nu($('#dynfields [data-dk="L"]').value),ang=angle('ang'),q=ang===null?Math.atan2(-(z[1]-a[1]),z[0]-a[0]):ang,l=L>0?L:oldL;p[n-1]=[a[0]+l*Math.cos(q),a[1]-l*Math.sin(q)]}
  }else if(s.t==='furn'){
    const cx=s.x+s.w/2,cy=s.y+s.h/2,w=nu($('#dynfields [data-dk="w"]').value),h=nu($('#dynfields [data-dk="h"]').value),a=angle('ang');if(w>0){s.w=w;s.x=cx-w/2}if(h>0){s.h=h;s.y=cy-h/2}if(a!==null)s.rot=a;
  }else if(s.t==='door'||s.t==='win'){
    const w=nu($('#dynfields [data-dk="w"]').value),a=angle('ang');if(w>0)s.w=w;if(a!==null)s.a=a;
  }else if(s.t==='text'||s.t==='north'){
    const h=nu($('#dynfields [data-dk="h"]').value),a=angle('ang');if(h>0)s.h=h;if(a!==null)s.a=a;
  }
  save();upd();draw();showDyn(s);
}

$('#dok').onclick=applyDyn;$('#dx').onclick=hideDyn;
